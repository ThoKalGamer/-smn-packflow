/**
 * SMN PackFlow v0.5 – Google Apps Script Backend
 * Ziel: bestehende "SMN Masterkalkulation"
 * Spreadsheet-ID ist fest hinterlegt.
 */

const SPREADSHEET_ID = '11gsYZBksa_ZL17qqTfW97MT5PGy03zwY9iU0nv76-l0';

function doGet() {
  return json_({
    ok: true,
    service: 'SMN PackFlow Backend',
    version: '0.5',
    spreadsheetId: SPREADSHEET_ID
  });
}

function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (body.action !== 'sync') throw new Error('Unbekannte Aktion');

    const state = body.payload || {};
    syncAll_(state);

    return json_({ok:true, syncedAt:new Date().toISOString()});
  } catch (err) {
    return json_({ok:false, error:String(err && err.message ? err.message : err)});
  }
}

function syncAll_(state) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);

  const products = (state.products || []).map(p => [
    p.id || '', p.code || '', p.name || '', p.status || '',
    num_(p.defaultSize), p.rawUnit || '', num_(p.shelfMonths),
    p.fefo !== false, p.packaging || '', p.labelNote || '', new Date()
  ]);
  replaceData_(ss, 'PF_Produkte',
    ['Produkt-ID','Code','Produktname','Status','Standard-g','Rohwaren-Einheit','MHD-Monate','FEFO','Verpackung','Etikett-Hinweis','Aktualisiert'],
    products);

  const raw = (state.raw || []).map(r => [
    r.id || '', date_(r.at || r.date), r.product || '', r.lot || '',
    r.mhd || '', num_(r.qty || r.kg), num_(r.remaining),
    r.supplier || '', r.location || '', r.status || '', r.employee || ''
  ]);
  replaceData_(ss, 'PF_Wareneingang',
    ['ID','Zeit','Produkt','LOT','MHD','Menge kg','Rest kg','Lieferant','Lagerort','Status','Mitarbeiter'],
    raw);

  const batches = (state.batches || []).map(b => [
    b.batch || '', date_(b.startedAt || b.at), date_(b.endedAt || b.finishedAt),
    b.product || '', num_(b.size), b.rawLot || b.lot || '',
    num_(b.rawKg || b.usedKg), num_(b.target || b.planned), num_(b.done),
    num_(b.lossG || b.loss), b.status || 'abgeschlossen', b.employee || ''
  ]);
  replaceData_(ss, 'PF_Chargen',
    ['Charge','Zeit Start','Zeit Ende','Produkt','Packung g','Rohwaren-LOT','Rohware kg','Soll Packungen','Ist Packungen','Ausschuss g','Status','Mitarbeiter'],
    batches);

  const byBatch = {};
  (state.batches || []).forEach(b => byBatch[b.batch] = b);

  const movements = (state.movements || []).map(m => {
    const b = byBatch[m.batch] || {};
    return [
      m.id || '', date_(m.at), m.type || '', m.batch || '', b.product || '',
      num_(m.qty), m.unit || '', m.from || '', m.to || '', m.location || '',
      m.target || m.channel || m.reason || '', m.note || '', m.employee || ''
    ];
  });
  replaceData_(ss, 'PF_Bewegungen',
    ['ID','Zeit','Typ','Charge','Produkt','Menge','Einheit','Von','Nach','Bestandsort','Ziel/Kanal/Grund','Notiz','Mitarbeiter'],
    movements);

  const stock = [];
  (state.batches || []).forEach(b => {
    Object.entries(b.stockByLocation || {}).forEach(([loc, qty]) => {
      stock.push([new Date(), b.batch || '', b.product || '', num_(b.size), loc, num_(qty), num_(qty) > 0 ? 'aktiv' : 'leer']);
    });
  });
  replaceData_(ss, 'PF_Bestand',
    ['Zeit','Charge','Produkt','Packung g','Bestandsort','Bestand Stk','Status'],
    stock);

  const syncSheet = ensureSheet_(ss, 'PF_Sync');
  syncSheet.getRange('A1:D3').clearContent();
  syncSheet.getRange(1,1,3,4).setValues([
    ['Schlüssel','Wert','Aktualisiert','Hinweis'],
    ['Spreadsheet-ID',SPREADSHEET_ID,new Date(),'SMN PackFlow Masterkalkulation'],
    ['PackFlow-Version','0.5',new Date(),'Letzte vollständige Synchronisierung']
  ]);
}

function replaceData_(ss, sheetName, headers, rows) {
  const sh = ensureSheet_(ss, sheetName);
  sh.clearContents();
  sh.getRange(1,1,1,headers.length).setValues([headers]);
  if (rows.length) sh.getRange(2,1,rows.length,headers.length).setValues(rows);
  sh.setFrozenRows(1);
}

function ensureSheet_(ss, name) {
  return ss.getSheetByName(name) || ss.insertSheet(name);
}

function num_(v) {
  const n = Number(v);
  return isFinite(n) ? n : 0;
}
function date_(v) {
  if (!v) return '';
  const d = new Date(v);
  return isNaN(d.getTime()) ? String(v) : d;
}
function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
