SMN PackFlow v0.5

Enthält alles aus v0.4 plus:
- Verbindung zur bestehenden SMN Masterkalkulation vorbereitet
- feste Spreadsheet-ID der Originaldatei hinterlegt
- Auto-Sync nach Änderungen
- manueller Sync-Button
- Sync-Status im Adminbereich
- Google Apps Script Backend beigefügt
- bestehende lokale Daten bleiben erhalten

Die bestehende Google-Tabelle wurde bereits erweitert um:
PF_Produkte
PF_Wareneingang
PF_Chargen
PF_Bewegungen
PF_Bestand
PF_Sync

WICHTIG:
Die Tabellenstruktur ist vorbereitet, aber für die automatische Live-Synchronisierung muss das
beigefügte Google Apps Script einmal als Web-App bereitgestellt werden. Die erzeugte /exec-URL
wird anschließend einmal im PackFlow-Adminbereich eingetragen. Danach kann Auto-Sync laufen.

GitHub:
Nur die index.html aus diesem Paket ersetzt die bisherige PackFlow-Datei.
